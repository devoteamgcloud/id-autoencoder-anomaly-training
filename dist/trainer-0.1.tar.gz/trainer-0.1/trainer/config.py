TRAIN_PATH = './train_data'
VAL_PATH = './val_data'
MODEL_PATH = './model'
