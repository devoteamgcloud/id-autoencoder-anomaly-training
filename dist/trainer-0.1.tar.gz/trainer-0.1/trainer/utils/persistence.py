# task.py
import argparse
import logging

from google.cloud import storage
from tensorflow import keras

import trainer.config as config

logger = logging.getLogger(__name__)

def save_model_and_reports(
    args: argparse.Namespace,
    model_name: str,
    history: keras.callbacks.History
) -> None:
    storage_client = storage.Client(project=args.project_id)
    bucket = storage_client.bucket(args.gcs_path)

    # Save model
    try:
        blob = bucket.blob(f"models/autoencoder/{model_name}")
        blob.upload_from_filename(f"{config.MODEL_PATH}/{model_name}")
        logger.info(f"Model saved to {args.gcs_path}/models/autoencoder/{model_name}")
    except Exception as e:
        logger.error(f"Failed to save model: {e}")

    # Save training report
    try:
        if history:
            blob = bucket.blob(f"reports/autoencoder/{args.curr_date_str}/{args.model_name}_{args.curr_date_str}.png")
            blob.upload_from_filename(f"{config.MODEL_PATH}/{args.model_name}_{args.curr_date_str}.png")
            logger.info(f"Training report saved to {args.gcs_path}/reports/autoencoder/{args.curr_date_str}/{args.model_name}_{args.curr_date_str}.png")
    except Exception as e:
        logger.error(f"Failed to save training report: {e}")

    # Save threshold report
    try:
        blob = bucket.blob(f"reports/autoencoder/{args.curr_date_str}/{args.model_name}_{args.curr_date_str}_error_distribution.png")
        blob.upload_from_filename(f"{config.MODEL_PATH}/{args.model_name}_{args.curr_date_str}_error_distribution.png")
        logger.info(f"Threshold report saved to {args.gcs_path}/reports/autoencoder/{args.curr_date_str}/{args.model_name}_{args.curr_date_str}_error_distribution.png")
    except Exception as e:
        logger.error(f"Failed to save threshold report: {e}")

    storage_client.close()
